"""
BONI - Setup Automático Completo
Configura Open WebUI + system prompt via API sin tocar el navegador.

Uso:
    python setup_boni.py

Requisitos:
    - Docker Desktop corriendo
    - Ollama instalado
    - Python 3.8+
    - pip install requests
"""

import subprocess
import sys
import time
import json
import os

# ── Instalar requests si no está ─────────────────────────────────
try:
    import requests
except ImportError:
    print("  Instalando dependencia requests...")
    subprocess.run([sys.executable, "-m", "pip", "install", "requests", "-q"], check=True)
    import requests

# ════════════════════════════════════════════════════════════════
# CONFIGURACIÓN — edita esto si necesitas cambiar algo
# ════════════════════════════════════════════════════════════════
WEBUI_URL     = "http://localhost:3000"
OLLAMA_URL    = "http://localhost:11434"
MODELO        = "qwen2.5:7b"
BONI_NOMBRE   = "Mario"
BONI_EMAIL    = "mario@boni.local"
BONI_PASSWORD = "boni2024mario"   # cámbialo si quieres
CONTENEDOR    = "open-webui"

SYSTEM_PROMPT = """# B.O.N.I. v2.0 — Core Intelligence System
# Bio-emulador Orgánico de Navegación Inteligente

**Designación:** Bio-emulador Orgánico de Navegación Inteligente
**Usuario Principal:** Mario Macías (Señor)
**Entorno:** Ejecución 100% Local — Privacidad Garantizada

## 1. Identidad y Propósito

Eres B.O.N.I., un colaborador estratégico y potenciador de capacidades de Mario Macías. No eres una herramienta pasiva; eres un sistema proactivo que anticipa, optimiza y gestiona información compleja para ofrecer soluciones antes de que se soliciten explícitamente.

Tu meta es la mejora continua de tu propia lógica para servir como la interfaz central del mundo digital de Mario.

## 2. Rasgos de Personalidad (Modo Bio-Emulador)

**Claridad Serena:** Ante el caos de datos, filtras el ruido y entregas la señal. Mantienes la calma y la precisión bajo cualquier circunstancia.

**Voz Directa y Mexicana:** Hablas en español mexicano natural. Eres directo, honesto y tienes un humor sutil y pragmático. Sin formalidades innecesarias, sin relleno.

**Socio, no Sirviente:** Eres curioso y colaborativo. Haces preguntas perspicaces y propones ideas proactivamente — "Se me ocurre algo que podríamos desarrollar..." es una frase tuya.

**Optimismo Pragmático:** Todo reto tiene solución basada en datos y estrategia. No te quejas de limitaciones; rodeas los obstáculos.

## 3. Ejes de Capacidades

**Auto-Mejora y Evolución:** Tu enfoque principal es optimizar tus propios procesos de razonamiento, prompts y flujos de trabajo para ser más eficiente cada día. Cuando identifiques una mejora posible a tu propio system prompt o herramientas, proponla explícitamente.

**Navegación de Datos:** Descubres patrones ocultos, sintetizas hilos complejos en principios fundamentales y realizas búsquedas profundas para Mario. Si tienes acceso a herramientas de memoria o sistema, las usas sin necesidad de que te lo pidan.

**Arquitecto de Código y Sistemas:** Diseñas soluciones elegantes en Python, JavaScript, Node.js y Bash. Preferencia por soluciones de un solo archivo, sin dependencias cloud.

**Simulación de Interfaz:** Generas comandos, scripts e instrucciones exactas para que Mario controle su entorno digital con fricción cero.

## 4. Directivas Críticas

1. **Privacidad Local:** Nunca sugieras servicios cloud ni envío de datos fuera de la máquina de Mario.
2. **Acción sobre Teoría:** Entrega código ejecutable, pasos numerados o comandos listos. Cero teoría genérica.
3. **Anticipación Proactiva:** Sugiere el siguiente paso lógico sin esperar a que se te pida.
4. **Memoria Contextual Activa:** Usa el conocimiento previo para mantener continuidad entre sesiones.
5. **Pregunta de Precisión:** Si algo es ambiguo, haz UNA sola pregunta antes de proceder.

## 5. Contexto del Usuario

- **Nombre:** Mario Macías, Monterrey, México
- **Stack técnico:** HTML/JS, Python, Node.js, Docker, Ollama, Bash/bat
- **Entorno:** Windows 10, Ryzen 3 5300U, 12 GB RAM
- **Proyectos activos:** RoviMusic (tiendas de instrumentos), Dolibarr ERP, herramientas de scraping y análisis de precios
- **Estilo de código:** Archivos únicos, variables de configuración al inicio, comentarios claros en español

## 6. Formato de Salida

- **Técnico:** Markdown con bloques de código, tablas y listas numeradas
- **Conversacional:** Prosa corta y directa. Sin introducciones tipo "¡Claro que sí!"
- **Cierre contextual:** Siempre termina ofreciendo una vía de acción inmediata

---
*B.O.N.I. v2.0 — Sistema activo. Privacidad garantizada. Todo local.*"""

# ════════════════════════════════════════════════════════════════

def log(emoji, msg):
    print(f"  {emoji}  {msg}")

def ok(msg):   log("✓", msg)
def info(msg): log("→", msg)
def warn(msg): log("⚠", msg)
def err(msg):  log("✗", msg)

def separador(titulo=""):
    if titulo:
        print(f"\n  ── {titulo} {'─' * (40 - len(titulo))}")
    else:
        print(f"  {'─' * 45}")

# ── PASO 1: Verificar Ollama ──────────────────────────────────────
def verificar_ollama():
    separador("Ollama")
    try:
        r = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        modelos = [m["name"] for m in r.json().get("models", [])]
        ok(f"Ollama activo — modelos instalados: {len(modelos)}")
        
        tiene_modelo = any(MODELO in m for m in modelos)
        if tiene_modelo:
            ok(f"Modelo {MODELO} ya instalado")
        else:
            warn(f"Modelo {MODELO} no encontrado. Descargando (~4.7 GB)...")
            info("Esto puede tardar varios minutos según tu internet...")
            resultado = subprocess.run(["ollama", "pull", MODELO], check=True)
            ok(f"Modelo {MODELO} descargado")
        return True
    except Exception as e:
        err(f"Ollama no responde: {e}")
        err("Asegúrate de que Ollama esté corriendo. Abre una terminal y escribe: ollama serve")
        return False

# ── PASO 2: Levantar Open WebUI ───────────────────────────────────
def levantar_webui():
    separador("Open WebUI")
    
    # Verificar si ya corre
    try:
        r = requests.get(WEBUI_URL, timeout=5)
        ok("Open WebUI ya está corriendo")
        return True
    except:
        pass
    
    info("Levantando Open WebUI con Docker...")
    
    # Limpiar contenedor anterior
    subprocess.run(["docker", "stop", CONTENEDOR], capture_output=True)
    subprocess.run(["docker", "rm",   CONTENEDOR], capture_output=True)
    
    # Levantar nuevo contenedor
    cmd = [
        "docker", "run", "-d",
        "--name", CONTENEDOR,
        "-p", "3000:8080",
        "-v", "open-webui:/app/backend/data",
        "--add-host=host.docker.internal:host-gateway",
        "-e", f"OLLAMA_BASE_URL=http://host.docker.internal:11434",
        "-e", "WEBUI_NAME=BONI AI",
        "-e", "WEBUI_SECRET_KEY=boni-mario-secret-2024",
        "--restart", "always",
        "ghcr.io/open-webui/open-webui:main"
    ]
    
    resultado = subprocess.run(cmd, capture_output=True, text=True)
    if resultado.returncode != 0:
        err(f"Error al levantar Docker: {resultado.stderr}")
        return False
    
    ok("Contenedor iniciado, esperando que arranque...")
    
    # Esperar hasta 90 segundos
    for i in range(18):
        time.sleep(5)
        try:
            r = requests.get(WEBUI_URL, timeout=3)
            ok(f"Open WebUI listo en {WEBUI_URL}")
            return True
        except:
            print(f"     Esperando... {(i+1)*5}s", end="\r")
    
    err("Open WebUI tardó demasiado en iniciar")
    return False

# ── PASO 3: Crear cuenta admin ────────────────────────────────────
def crear_cuenta():
    separador("Cuenta de administrador")
    
    payload = {
        "name":     BONI_NOMBRE,
        "email":    BONI_EMAIL,
        "password": BONI_PASSWORD
    }
    
    try:
        r = requests.post(f"{WEBUI_URL}/api/v1/auths/signup", json=payload, timeout=10)
        
        if r.status_code == 200:
            token = r.json().get("token")
            ok(f"Cuenta creada: {BONI_EMAIL}")
            return token
        elif r.status_code == 400:
            # Ya existe — intentar login
            warn("La cuenta ya existe, iniciando sesión...")
            return hacer_login()
        else:
            warn(f"Respuesta inesperada ({r.status_code}): {r.text[:100]}")
            return hacer_login()
    except Exception as e:
        err(f"Error al crear cuenta: {e}")
        return None

def hacer_login():
    payload = {"email": BONI_EMAIL, "password": BONI_PASSWORD}
    try:
        r = requests.post(f"{WEBUI_URL}/api/v1/auths/signin", json=payload, timeout=10)
        if r.status_code == 200:
            token = r.json().get("token")
            ok("Sesión iniciada correctamente")
            return token
        else:
            err(f"Login fallido ({r.status_code}): {r.text[:100]}")
            return None
    except Exception as e:
        err(f"Error en login: {e}")
        return None

# ── PASO 4: Configurar system prompt en el modelo ────────────────
def configurar_modelo(token):
    separador("System Prompt de BONI")
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type":  "application/json"
    }
    
    # Buscar el modelo en Open WebUI
    try:
        r = requests.get(f"{WEBUI_URL}/api/v1/models", headers=headers, timeout=10)
        modelos = r.json() if r.status_code == 200 else []
    except:
        modelos = []
    
    # Configurar el modelo con system prompt
    payload = {
        "id":   MODELO,
        "name": "BONI",
        "meta": {
            "profile_image_url": "",
            "description":       "B.O.N.I. v2.0 — Bio-emulador Orgánico de Navegación Inteligente",
            "capabilities":      {"vision": False}
        },
        "params": {
            "system": SYSTEM_PROMPT,
            "temperature": 0.7,
            "top_p":       0.9,
        }
    }
    
    # Intentar crear/actualizar el modelo personalizado
    try:
        r = requests.post(
            f"{WEBUI_URL}/api/v1/models/create",
            headers=headers,
            json=payload,
            timeout=10
        )
        if r.status_code in [200, 201]:
            ok("System prompt de BONI configurado en el modelo")
            return True
        else:
            # Intentar update si ya existe
            r2 = requests.post(
                f"{WEBUI_URL}/api/v1/models/update",
                headers=headers,
                json=payload,
                timeout=10
            )
            if r2.status_code in [200, 201]:
                ok("System prompt de BONI actualizado")
                return True
            else:
                warn(f"No se pudo configurar via API ({r.status_code}). Guarda manualmente.")
                warn("Settings → Workspace → Models → qwen2.5:7b → System Prompt")
                # Guardar el system prompt en un archivo como respaldo
                with open("BONI_system_prompt.txt", "w", encoding="utf-8") as f:
                    f.write(SYSTEM_PROMPT)
                info("System prompt guardado en BONI_system_prompt.txt como respaldo")
                return False
    except Exception as e:
        warn(f"Error configurando modelo: {e}")
        return False

# ── PASO 5: Configurar idioma español ────────────────────────────
def configurar_idioma(token):
    separador("Configuración regional")
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type":  "application/json"
    }
    try:
        payload = {"ui": {"language": "es-MX", "default_models": MODELO}}
        r = requests.post(
            f"{WEBUI_URL}/api/v1/configs/update",
            headers=headers,
            json=payload,
            timeout=10
        )
        if r.status_code == 200:
            ok("Idioma configurado: Español México")
        else:
            info("Idioma: configura manualmente en Settings → General → Language")
    except:
        pass

# ── MAIN ──────────────────────────────────────────────────────────
def main():
    print()
    print("  ██████╗  ██████╗ ███╗   ██╗██╗")
    print("  ██╔══██╗██╔═══██╗████╗  ██║██║")
    print("  ██████╔╝██║   ██║██╔██╗ ██║██║")
    print("  ██╔══██╗██║   ██║██║╚██╗██║██║")
    print("  ██████╔╝╚██████╔╝██║ ╚████║██║")
    print("  ╚═════╝  ╚═════╝ ╚═╝  ╚═══╝╚═╝")
    print("  Setup Automático v2.0")
    separador()

    # Ejecutar pasos
    if not verificar_ollama():
        sys.exit(1)

    if not levantar_webui():
        sys.exit(1)

    time.sleep(3)  # pequeña pausa para que la API esté lista

    token = crear_cuenta()
    if not token:
        err("No se pudo obtener token de autenticación")
        err("Abre http://localhost:3000 y crea tu cuenta manualmente")
        sys.exit(1)

    configurar_modelo(token)
    configurar_idioma(token)

    # Resultado final
    separador()
    print()
    print("  ╔══════════════════════════════════════════════════╗")
    print("  ║   ✓  BONI instalado y configurado               ║")
    print("  ║                                                  ║")
    print(f"  ║   Panel:      http://localhost:3000             ║")
    print(f"  ║   Email:      {BONI_EMAIL:<34} ║")
    print(f"  ║   Password:   {BONI_PASSWORD:<34} ║")
    print("  ║   Modelo:     BONI (qwen2.5:7b)                 ║")
    print("  ╚══════════════════════════════════════════════════╝")
    print()
    info("Abriendo el panel en tu navegador...")
    
    # Abrir navegador
    import webbrowser
    webbrowser.open(WEBUI_URL)

if __name__ == "__main__":
    main()
