@echo off
chcp 65001 >nul
title BONI - Setup Automático

color 0A
echo.
echo  Iniciando setup de BONI...
echo.

REM ── Verificar Python ─────────────────────────────────────────
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [!] Python no encontrado. Instalando...
    curl -L -o "%TEMP%\python_installer.exe" "https://www.python.org/ftp/python/3.11.9/python-3.11.9-amd64.exe"
    "%TEMP%\python_installer.exe" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1
    echo  [OK] Python instalado. Reinicia el script.
    pause
    exit /b
)

REM ── Ejecutar setup ───────────────────────────────────────────
python "%~dp0setup_boni.py"

echo.
pause
